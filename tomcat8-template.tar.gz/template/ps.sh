#!/bin/sh

SCRIPTPATH=`cd $(dirname $0) ; pwd -P`
SCRIPT=$SCRIPTPATH/$(basename $0)
ARGUMENTS=$@

. ${SCRIPTPATH}/env.sh

SETUSER=${WAS_USER}
RUNNER=`whoami`

if [ ${RUNNER} != ${SETUSER} ] ;
   then echo "Deny Access : [ ${RUNNER} ]. Not ${SETUSER}" ;
   exit 0 ;
fi

ps -ef | grep java | grep catalina.home=${CATALINA_HOME}
