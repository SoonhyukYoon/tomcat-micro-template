#!/bin/sh

SCRIPTPATH=`cd $(dirname $0) ; pwd -P`
SCRIPT=$SCRIPTPATH/$(basename $0)
ARGUMENTS=$@

. ${SCRIPTPATH}/env.sh

SETUSER=${WAS_USER}
RUNNER=`whoami`

if [ ${RUNNER} != ${SETUSER} ] ;
   then echo "Deny Access : [ ${RUNNER} ]. Not ${SETUSER}" ;
   exit 0 ;
fi

ps_check(){
 ps -ef | grep java | grep "was_cname=${INST_NAME} "| wc -l
}

[ `ps_check` -eq 0 ] && echo "##### ERROR. ${INST_NAME} is not running. There is nothing to stop.#######" && exit 1

##  Tomcat shutdwn command
${CATALINA_HOME}/bin/shutdown.sh ${ARGUMENTS}

# ps -ef | grep java | grep "was_cname=${INST_NAME} " | awk {'print "kill -9 " $2'} | sh -x
# rm -f ${CATALINA_PID}

echo "Execute ./stop.sh by [ `who am i` ]" >> ${LOG_HOME}/catalina.${LOG_DATE}.log

if [ `ps_check` -eq 0 ];
 then echo "##### ${INST_NAME} successfully shut down ###### "
 else echo "##### Fail to stop ${INST_NAME}!!  Check Again!! ###### "
fi
