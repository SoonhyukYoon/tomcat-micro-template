#!/bin/bash

# 해당 파일에 정의되어 있지 않은 환경변수는 start.sh 을 참조한다

## Business System Base Environment (modify them)
# JDK 설치 경로
export JAVA_HOME=/usr/local/java/jdk1.7.0_80
# 응용 프로그램 약어 = 본 서버에 탑재될 응용프로그램의 약어
export APP_SHORT_NAME=service
# 응용 프로그램 이름 = 각 Java 프로젝트 이름과 동일
export APP_LONG_NAME=something-service
# 서버 포트 = 8080을 기준으로 일반적으로 서버 증가마다 100씩 증가
export SERVICE_PORT=8080
# 서버 ID = '응용 프로그램 약어'_'포트'
export SERVER_ID=${APP_SHORT_NAME}_${SERVICE_PORT}
# WAS 실행 유저
export WAS_USER=wasadm
# 현재 Tomcat 인스턴스 설치 경로 (디렉토리 생성 필요. 상위 디렉토드 수정주의)
export INSTALL_PATH=/engn001/${WAS_USER}/tomcat8/servers/${SERVER_ID}
# JVM Route = '응용 프로그램 약어' + 01 (동일한 서버를 추가 설치시 1씩 추가)
export JVM_ROUTE=${APP_SHORT_NAME}01


## Business System Application Environment (modify them but change carefully)
# Tomcat 서버에 탑제할 응용 프로그램(war 파일)의 전체 경로 (디렉토리 생성 필요. 수정주의)
export APP_PATH=/srcw001/${WAS_USER}/${APP_LONG_NAME}/applications/ROOT.war
# JDBC Driver Class
# ~/lib/datasource 디렉터리에는 아래와 같은 Lib를 제공한다.
# - MariaDB: mariadb-java-client-1.5.4.jar
# - MySQL: mysql-connector-java-5.1.40.jar
# - PostgreSQL: postgresql-9.4.1211.jre7.jar
# - MS SQL Server: sqljdbc41.jar
#
# 아래는 MariaDB 예시
export JDBC_DRIVER="org.mariadb.jdbc.Driver"
# DB 접속 URL (수정주의) 아래는 MariaDB 예시
export JDBC_URL="jdbc:mariadb://127.0.0.1:3306/DB_NAME?connectTimeout=5000&amp;socketTimeout=10000"
# DB 접속 계정
export JDBC_USERNAME="USERNAME"
# DB 접속 패스워드
export JDBC_PASSWORD="PASSWORD"
# Max Threads (수정주의: The maximum number of request processing threads to be created by HTTP Connector)
export MAX_THREADS=1024
# Spring Application Profile (서버 환경에 따라 설정 = 개발환경: dev, QA환경: qa, 운영환경: prod)
export APP_PROFILE=dev


# Tomcat/GC Log Timestamp
export LOG_DATE=`date +%Y-%m-%d`
export DATE=`date +%Y-%m-%d_%H-%M-%S`

## Catalina Environment (don't modify them)
export PATH=${PATH}:.
export CATALINA_HOME=${INSTALL_PATH}
export CATALINA_BASE=${CATALINA_HOME}
export INST_NAME=${SERVER_ID}_`hostname`
export LOG_HOME=${CATALINA_HOME}/logs
export CATALINA_OUT=${LOG_HOME}/${INST_NAME}.out
export CATALINA_PID=${CATALINA_HOME}/${INST_NAME}.pid

## Catalina Java Options (don't modify them)
JAVA_OPTS=" ${JAVA_OPTS} -server"
JAVA_OPTS=" ${JAVA_OPTS} -DjvmRoute=${JVM_ROUTE}"
JAVA_OPTS=" ${JAVA_OPTS} -Dwas_cname=${INST_NAME}"
JAVA_OPTS=" ${JAVA_OPTS} -Dport.http=${SERVICE_PORT}"
JAVA_OPTS=" ${JAVA_OPTS} -Dport.https=`expr ${SERVICE_PORT} + 363`"
JAVA_OPTS=" ${JAVA_OPTS} -Dport.ajp=`expr ${SERVICE_PORT} - 71`"
JAVA_OPTS=" ${JAVA_OPTS} -Dport.shutdown=`expr ${SERVICE_PORT} - 75`"
JAVA_OPTS=" ${JAVA_OPTS} -Dpath.application=${APP_PATH}"
JAVA_OPTS=" ${JAVA_OPTS} -Djdbc.driver=\"${JDBC_DRIVER}\""
JAVA_OPTS=" ${JAVA_OPTS} -Djdbc.url=\"${JDBC_URL}\""
JAVA_OPTS=" ${JAVA_OPTS} -Djdbc.username=${JDBC_USERNAME}"
JAVA_OPTS=" ${JAVA_OPTS} -Djdbc.password=${JDBC_PASSWORD}"
JAVA_OPTS=" ${JAVA_OPTS} -Dhttp.maxthread=${MAX_THREADS}"
JAVA_OPTS=" ${JAVA_OPTS} -Dspring.profiles.active=${APP_PROFILE}"

export JAVA_OPTS
