#!/bin/bash

# 해당 파일에 정의되어 있지 않은 환경변수는 start.sh 을 참조한다

## Business System Base Environment (modify them)
# JDK 설치 경로
export JAVA_HOME=/usr/local/java/jdk1.7.0_80
# 응용 프로그램 약어 = 본 서버에 탑재될 응용프로그램의 약어
export APP_SHORT_NAME=service
# 응용 프로그램 이름 = 각 Java 프로젝트 이름과 동일
export APP_LONG_NAME=something-service
# 서버 포트 = 8080을 기준으로 일반적으로 서버 증가마다 100씩 증가
export SERVICE_PORT=8080
# 서버 ID = '응용 프로그램 약어'_'포트'
export SERVER_ID=${APP_SHORT_NAME}_${SERVICE_PORT}
# 현재 Tomcat 인스턴스 설치 경로
export INSTALL_PATH=/engn001/wasadm/tomcat8/servers/${SERVER_ID}
# WAS 실행 유저
export WAS_USER=wasadm
# JVM Route = '응용 프로그램 약어' + 01 (동일한 서버를 추가 설치시 1씩 추가)
export JVM_ROUTE=${APP_SHORT_NAME}01


## Business System Application Environment (modify them but change carefully)
# ROOT.war 파일이 저장되어있는 디렉토리 (디렉토리 생성 필요. 수정주의)
export APP_PATH=/srcw001/wasadm/${APP_LONG_NAME}/applications
# DB 접속 URL (수정주의) 아래는 MariaDB 예시
export JDBC_URL="jdbc:mariadb://127.0.0.1:3306/DB_NAME?connectTimeout=5000&amp;socketTimeout=10000"
# DB 접속 계정
export JDBC_USERNAME="USERNAME"
# DB 접속 패스워드
export JDBC_PASSWORD="PASSWORD"
# Max Threads (수정주의: The maximum number of request processing threads to be created by HTTP Connector)
export MAX_THREADS=1024
# Spring Application Profile (서버 환경에 따라 설정 = 개발환경: dev, QA환경: qa, 운영환경: prod)
export APP_PROFILE=dev
#
# Optional: Quartz Cluster를 사용하는 경우 주석해제 (~/conf/Catalina/localhost/ROOT.xml 파일과 함께 수정필요)
# 
# Quartz Cluster DB 접속 URL (수정주의) 아래는 MariaDB 예시
#export JDBC_QUARTZ_URL="jdbc:mariadb://127.0.0.1:3306/QUARTZ_DB_NAME?connectTimeout=5000&amp;socketTimeout=10000"
# Quartz Cluster DB 접속 계정
#export JDBC_QUARTZ_USERNAME="USERNAME"
# Quartz Cluster DB 접속 패스워드
#export JDBC_QUARTZ_PASSWORD="PASSWORD"


# Tomcat/GC Log Timestamp
export LOG_DATE=`date +%Y-%m-%d`
export DATE=`date +%Y-%m-%d_%H-%M-%S`

## Catalina Environment (don't modify them)
export PATH=${PATH}:.
export CATALINA_HOME=${INSTALL_PATH}
export CATALINA_BASE=${CATALINA_HOME}
export INST_NAME=${SERVER_ID}_`hostname`
export LOG_HOME=${CATALINA_HOME}/logs
export CATALINA_OUT=${LOG_HOME}/${INST_NAME}.out
export CATALINA_PID=${CATALINA_HOME}/${INST_NAME}.pid

## Catalina Java Options (don't modify them)
JAVA_OPTS=" ${JAVA_OPTS} -server"
JAVA_OPTS=" ${JAVA_OPTS} -DjvmRoute=${JVM_ROUTE}"
JAVA_OPTS=" ${JAVA_OPTS} -Dwas_cname=${INST_NAME}"
JAVA_OPTS=" ${JAVA_OPTS} -Dport.http=${SERVICE_PORT}"
JAVA_OPTS=" ${JAVA_OPTS} -Dport.https=`expr ${SERVICE_PORT} + 363`"
JAVA_OPTS=" ${JAVA_OPTS} -Dport.ajp=`expr ${SERVICE_PORT} - 71`"
JAVA_OPTS=" ${JAVA_OPTS} -Dport.shutdown=`expr ${SERVICE_PORT} - 75`"
JAVA_OPTS=" ${JAVA_OPTS} -Dpath.application=${APP_PATH}"
JAVA_OPTS=" ${JAVA_OPTS} -Djdbc.url=\"${JDBC_URL}\""
JAVA_OPTS=" ${JAVA_OPTS} -Djdbc.username=${JDBC_USERNAME}"
JAVA_OPTS=" ${JAVA_OPTS} -Djdbc.password=${JDBC_PASSWORD}"
JAVA_OPTS=" ${JAVA_OPTS} -Dhttp.maxthread=${MAX_THREADS}"
JAVA_OPTS=" ${JAVA_OPTS} -Dspring.profiles.active=${APP_PROFILE}"
if [ ! -z "$JDBC_QUARTZ_URL" ] ;
then JAVA_OPTS=" ${JAVA_OPTS} -Djdbc.quartz.url=\"${JDBC_QUARTZ_URL}\""
fi
if [ ! -z "$JDBC_QUARTZ_USERNAME" ] ;
then JAVA_OPTS=" ${JAVA_OPTS} -Djdbc.quartz.username=${JDBC_QUARTZ_USERNAME}"
fi
if [ ! -z "$JDBC_QUARTZ_PASSWORD" ] ;
then JAVA_OPTS=" ${JAVA_OPTS} -Djdbc.quartz.password=${JDBC_QUARTZ_PASSWORD}"
fi

export JAVA_OPTS
