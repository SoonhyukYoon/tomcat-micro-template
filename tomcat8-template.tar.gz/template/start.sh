#!/bin/sh

SCRIPTPATH=`cd $(dirname $0) ; pwd -P`
SCRIPT=$SCRIPTPATH/$(basename $0)
ARGUMENTS=$@

. ${SCRIPTPATH}/env.sh

SETUSER=${WAS_USER}
RUNNER=`whoami`

if [ ${RUNNER} != ${SETUSER} ] ;
   then echo "Deny Access : [ ${RUNNER} ]. Not ${SETUSER}" ;
   exit 0 ;
fi

ps_check(){
 ps -ef | grep java | grep "was_cname=${INST_NAME} "| wc -l
}

[ `ps_check` -gt 0 ] && echo "##### ERROR. ${INST_NAME} is already running. exiting.. #####" && exit 1

# Move Old GC Log
if [ 0 -eq `ls ${LOG_HOME} | grep gc_${INST_NAME} | wc -l` ]; then
  echo "Previous GC log does not exist"
else
  mv ${LOG_HOME}/gc_${INST_NAME}*.log ${LOG_HOME}/gclog
fi

# Move Old Catalina Log
if [ 0 -eq `ls ${LOG_HOME} | grep ^catalina\.*\.log | wc -l` ]; then
  echo "Previous log does not exist"
else
  cd ${LOG_HOME}
  for LOG_FILE in `ls *.log | grep -v "${LOG_DATE}"`
  do
    mv ${LOG_FILE} nohup/${LOG_FILE}.${DATE}
  done
fi

# Template file clean
rm -rf ${CATALINA_BASE}/temp/*
rm -rf ${CATALINA_BASE}/webapps/*
rm -rf ${CATALINA_BASE}/work/*

# Jenkins 에서 Remote Booting시 Process Hang 방지
if [ "$1" = "-boot_on_jenkins" ]
then
    nohup ${CATALINA_HOME}/bin/startup.sh  > /dev/null 2>&1 &
    while [ ! -f $CATALINA_PID ]
    do
        sleep 0.1
    done
    echo "[INFO] Tomcat Booted on Jeknins!"
else
    ${CATALINA_HOME}/bin/startup.sh
fi

if [ -z `cat $CATALINA_PID` ]; then
        #echo "PID_MAKING..."
        echo `ps -ef | grep java | grep ${CATALINA_BASE} | grep was_cname=${INST_NAME} | awk {'print $2'}` > "$CATALINA_PID"
fi
